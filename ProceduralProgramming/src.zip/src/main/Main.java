package main;

import calculator.Calculator;

public class Main {
	public static void main(String[] args) {
		// create object
		Calculator calculator;
		calculator = new Calculator();
		
		calculator.add();
		
//		int x[];
//		x = new int[10];
//		
//		for (int i=0; i<10; i++) {
//			x[i] = i;
//		}
//		for (int i=0; i<10; i++) {
//			System.out.println(x[i]);
//		}
	}
}

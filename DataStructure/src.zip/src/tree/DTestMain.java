package tree;

public class DTestMain {
	public void execute() {
		DTree tree = new DTree();
		tree.build();
	}
}

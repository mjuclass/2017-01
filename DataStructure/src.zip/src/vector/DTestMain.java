package vector;

public class DTestMain {
	public void execute() {		
//		try {
//			DVectorGeneric<Float> dVector = new DVectorGeneric<Float>();
//			for (int i = 0; i < 10; i++) {
//				dVector.add((float) (i * 10));
//			}
//			// data validation
//			System.out.println("size: "+dVector.getSize());
//			for (int i = 0; i < dVector.getSize(); i++) {
//				System.out.println("index-" + i + ": "+dVector.get(i));
//			}
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}	
	}
}

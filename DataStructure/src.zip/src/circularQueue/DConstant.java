package circularQueue;

public class DConstant {
	public final static int QUEUE_SIZE = 3;
	public final static String EMSG_ARRAYINDEXOUTOFBOUNDS = "ArrayIndexOutOfBounds";
}

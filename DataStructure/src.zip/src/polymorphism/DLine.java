package polymorphism;

public class DLine extends DShape {

	@Override
	public void draw() {
		System.out.println(this.getClass().getName());
	}

}

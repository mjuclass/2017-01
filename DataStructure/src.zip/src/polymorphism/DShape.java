package polymorphism;

public class DShape {	
	public void draw() {
		System.out.println(this.getClass().getName());
	}
}

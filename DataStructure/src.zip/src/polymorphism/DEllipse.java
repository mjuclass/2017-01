package polymorphism;

public class DEllipse extends DShape {

	@Override
	public void draw() {
		System.out.println(this.getClass().getName());
	}

}

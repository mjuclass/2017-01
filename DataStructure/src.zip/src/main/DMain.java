package main;

import tree.DTestMain;

public class DMain {
	public static void main(String[] args) {
		DTestMain testMain = new DTestMain();
		testMain.execute();
	}
}

package objectVector;

public class DConstant {
	final static int VECTOR_SIZE = 10;
	final static String EMSG_ARRAYINDEXOUTOFBOUNDS = "ArrayIndexOutOfBounds";
}
